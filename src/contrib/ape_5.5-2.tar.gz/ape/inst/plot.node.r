if (FALSE){
library("TreeTools", quietly = TRUE, warn.conflicts = FALSE)

plot(BalancedTree(8), node.col = c(1, 1, 1, 1, 2, 2, 2, 3,
                                   2, 2, 1, 1, 2, 3, 3))

plot(TreeTools::BalancedTree(10))
plot(BalancedTree(10), node.color = 'red')
plot(BalancedTree(10), node.color = c(rep('red', 10), rep('grey', 4), rep('red', 4), 'green'))
plot(CollapseNode(BalancedTree(10), 18),
     direction = 'upwards',
     node.color = c(rep('red', 10), rep('grey', 4), rep('red', 2), 'green', 'red'))
plot(CollapseNode(BalancedTree(10), 18),
     edge.color = 'black',
     node.color = c(rep('red', 10), rep('grey', 4), rep('red', 2), 'green', 'red'))

plot(CollapseNode(BalancedTree(10), 18),
     direction = 'upwards',
     edge.color = viridisLite::plasma(18),
     node.color = c(rep('blue', 10), rev(viridisLite::inferno(9))),
     node.lty = c(rep('solid', 15), rep('dotted', 1), rep('dashed', 2)),
     edge.lty = 'solid',
     node.width = c(rep(1, 10), 1:8),
     edge.width = (1:17) / 2
     )


nodelabels(node.color, 1:19); edgelabels(colors$h)
nodelabels()


x <- CollapseNode(BalancedTree(10), 18)
x <- TreeTools::BalancedTree(8)
edge <- x$edge
Ntip <- TreeTools::NTip(x)
Nnode <- x$Nnode


type = "phylogram"
use.edge.length = TRUE

node.pos = NULL
 show.tip.label = TRUE
 show.node.label = FALSE

edge.color = NULL
 edge.width = NULL
 edge.lty = NULL

node.color = NULL
 node.width = NULL
 node.lty = NULL

font = 3
 cex = par("cex")

adj = NULL
 srt = 0
 no.margin = FALSE
 root.edge = FALSE

label.offset = 0
 underscore = FALSE
 x.lim = NULL

y.lim = NULL
 direction = "rightwards"
 lab4ut = NULL

tip.color = par("col")
 plot = TRUE
 rotate.tree = 0

open.angle = 0
 node.depth = 1
 align.tip.label = FALSE

 horizontal = TRUE

#BalancedTree(8)
xx <- (c(rep(4, 8), 1, 2, 3, 3, 2, 3, 3) - 1) * 2
yy <- c(1:8, 4.5, 2.5, 1.5, 3.5, 6.5, 5.5, 7.5)

#CollapseNode(BalancedTree(10))
xx <- (c(rep(4, 10), 1, 2, 3, 3, 2, 3, 3) - 1) * 2
yy <- c(1:8, 4.5, 2.5, 1.5, 3.5, 6.5, 5.5, 7.5)




nodelabels()
}
