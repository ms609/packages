library('testthat')
library('ape')

test_check("ape")
