# TreeDist 1.0.0

Initial release, building on some draft functions included in 
'[TreeSearch](https://ms609.github.io/TreeSearch)' 0.3.2.9005.