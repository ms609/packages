# TBRDist 1.0.0

- Initial implementation of distances on unrooted trees.
