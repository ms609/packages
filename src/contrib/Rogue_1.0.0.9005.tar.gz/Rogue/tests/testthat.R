library('testthat')
library('Rogue')

test_check("Rogue")
