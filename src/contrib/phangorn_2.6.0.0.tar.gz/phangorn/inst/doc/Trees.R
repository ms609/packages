### R code from vignette source 'Trees.Rnw'

###################################################
### code chunk number 1: Trees.Rnw:74-77
###################################################
options(width=70)
foo <- packageDescription("phangorn")
options("show.signif.stars" = FALSE)


###################################################
### code chunk number 2: Trees.Rnw:97-102
###################################################
library(ape)
library(phangorn)
fdir <- system.file("extdata/trees", package = "phangorn")
primates <- read.phyDat(file.path(fdir, "primates.dna"),
                        format = "interleaved")


###################################################
### code chunk number 3: Trees.Rnw:108-111
###################################################
dm  <- dist.ml(primates)
treeUPGMA  <- upgma(dm)
treeNJ  <- NJ(dm)


###################################################
### code chunk number 4: plotNJ
###################################################
layout(matrix(c(1,2), 2, 1), height=c(1,2))
par(mar = c(0,0,2,0)+ 0.1)
plot(treeUPGMA, main="UPGMA")
plot(treeNJ, "unrooted", main="NJ")


###################################################
### code chunk number 5: figNJ
###################################################
getOption("SweaveHooks")[["fig"]]()
layout(matrix(c(1,2), 2, 1), height=c(1,2))
par(mar = c(0,0,2,0)+ 0.1)
plot(treeUPGMA, main="UPGMA")
plot(treeNJ, "unrooted", main="NJ")


###################################################
### code chunk number 6: Trees.Rnw:133-135
###################################################
parsimony(treeUPGMA, primates)
parsimony(treeNJ, primates)


###################################################
### code chunk number 7: Trees.Rnw:138-141
###################################################
treePars  <- optim.parsimony(treeUPGMA, primates)
treeRatchet  <- pratchet(primates, trace = 0)
parsimony(c(treePars, treeRatchet), primates)


###################################################
### code chunk number 8: Trees.Rnw:144-145 (eval = FALSE)
###################################################
## (trees <- bab(subset(primates,1:10)))


###################################################
### code chunk number 9: Trees.Rnw:151-153
###################################################
fit = pml(treeNJ, data=primates)
fit


###################################################
### code chunk number 10: Trees.Rnw:156-157
###################################################
methods(class="pml")


###################################################
### code chunk number 11: Trees.Rnw:160-162
###################################################
fitJC  <- optim.pml(fit, TRUE)
logLik(fitJC)


###################################################
### code chunk number 12: Trees.Rnw:165-169
###################################################
fitGTR <- update(fit, k=4, inv=0.2)
fitGTR <- optim.pml(fitGTR, model="GTR", optInv=TRUE, optGamma=TRUE,
    rearrangement = "NNI", control = pml.control(trace = 0))
fitGTR


###################################################
### code chunk number 13: Trees.Rnw:174-177
###################################################
fitGTR <- optim.pml(fitGTR, model="GTR", optInv=TRUE, optGamma=TRUE,
    rearrangement = "stochastic", control = pml.control(trace = 0))
fitGTR


###################################################
### code chunk number 14: Trees.Rnw:181-182
###################################################
anova(fitJC, fitGTR)


###################################################
### code chunk number 15: Trees.Rnw:185-186
###################################################
SH.test(fitGTR, fitJC)


###################################################
### code chunk number 16: Trees.Rnw:189-193
###################################################
AIC(fitJC)
AIC(fitGTR)
AICc(fitGTR)
BIC(fitGTR)


###################################################
### code chunk number 17: Trees.Rnw:196-197
###################################################
load("Trees.RData")


###################################################
### code chunk number 18: Trees.Rnw:199-200 (eval = FALSE)
###################################################
## mt = modelTest(primates)


###################################################
### code chunk number 19: Trees.Rnw:204-206
###################################################
library(xtable)
print(xtable(mt, caption="Summary table of modelTest", label="tab:modelTest"), include.rownames=FALSE)


###################################################
### code chunk number 20: Trees.Rnw:210-213
###################################################
env <- attr(mt, "env")
ls(envir=env)
(fit <- eval(get("HKY+G+I", env), env))


###################################################
### code chunk number 21: Trees.Rnw:216-218 (eval = FALSE)
###################################################
## bs = bootstrap.pml(fitJC, bs=100, optNni=TRUE,
##     control = pml.control(trace = 0))


###################################################
### code chunk number 22: plotBS
###################################################
par(mfrow=c(2,1))
par(mar=c(1,1,3,1))
plotBS(midpoint(fitJC$tree), bs, p = 50, type="p")
title("a)")
cnet <- consensusNet(bs, p=0.2)
plot(cnet, "2D", show.edge.label=TRUE)
title("b)")


###################################################
### code chunk number 23: figBS
###################################################
getOption("SweaveHooks")[["fig"]]()
par(mfrow=c(2,1))
par(mar=c(1,1,3,1))
plotBS(midpoint(fitJC$tree), bs, p = 50, type="p")
title("a)")
cnet <- consensusNet(bs, p=0.2)
plot(cnet, "2D", show.edge.label=TRUE)
title("b)")


###################################################
### code chunk number 24: Trees.Rnw:249-251
###################################################
options(prompt=" ")
options(continue="  ")


###################################################
### code chunk number 25: Trees.Rnw:253-282 (eval = FALSE)
###################################################
## library(phangorn)
## file="myfile"
## dat = read.phyDat(file)
## dm = dist.ml(dat, "F81")
## tree = NJ(dm)
## # as alternative for a starting tree:
## tree <- pratchet(dat)          # parsimony tree
## tree <- nnls.phylo(tree, dm)   # need edge weights
## 
## 
## # 1. alternative: quick and dirty: GTR + G
## fitStart = pml(tree, dat, k=4)
## fit = optim.pml(fitStart, model="GTR", optGamma=TRUE, rearrangement="stochastic")
## 
## # 2. alternative: preper with modelTest
## mt <- modelTest(dat, tree=tree, multicore=TRUE)
## mt[order(mt$AICc),]
## # choose best model from the table according to AICc
## bestmodel <- mt$Model[which.min(mt$AICc)]
## 
## env = attr(mt, "env")
## fitStart = eval(get("GTR+G+I", env), env)
## 
## # or let R search the table
## fitStart = eval(get(bestmodel, env), env)
## # equivalent to:   fitStart = eval(get("GTR+G+I", env), env)
## fit = optim.pml(fitStart, rearrangement = "stochastic",
##     optGamma=TRUE, optInv=TRUE, model="GTR")
## bs = bootstrap.pml(fit, bs=100, optNni=TRUE, multicore=TRUE)


###################################################
### code chunk number 26: Trees.Rnw:288-309 (eval = FALSE)
###################################################
## library(phangorn)
## file="myfile"
## dat = read.phyDat(file, type = "AA")
## dm = dist.ml(dat, model="JTT")
## tree = NJ(dm)
## 
## # parallel will only work safely from command line
## # and not at all windows
## (mt <- modelTest(dat, model=c("JTT", "LG", "WAG"),
##     multicore=TRUE))
## # run all available amino acid models
## (mt <- modelTest(dat, model="all", multicore=TRUE))
## 
## fitStart = eval(get(mt$Model[which.min(mt$BIC)], env), env)
## 
## fitNJ = pml(tree, dat, model="JTT", k=4, inv=.2)
## fit = optim.pml(fitNJ, rearrangement = "stochastic",
##     optInv=TRUE, optGamma=TRUE)
## fit
## 
## bs = bootstrap.pml(fit, bs=100, optNni=TRUE, multicore=TRUE)


###################################################
### code chunk number 27: Trees.Rnw:312-314
###################################################
options(prompt="> ")
options(continue="+ ")


###################################################
### code chunk number 28: Trees.Rnw:326-327
###################################################
toLatex(sessionInfo())


