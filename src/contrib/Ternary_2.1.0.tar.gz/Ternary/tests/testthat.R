library("testthat")
library("Ternary")

test_check("Ternary")
