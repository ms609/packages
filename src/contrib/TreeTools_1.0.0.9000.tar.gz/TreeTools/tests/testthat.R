library('testthat')
library('ape')
library('TreeTools')

suppressPackageStartupMessages(test_check("TreeTools"))
