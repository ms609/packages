library(shinytest)
shinytest::testApp("../")

