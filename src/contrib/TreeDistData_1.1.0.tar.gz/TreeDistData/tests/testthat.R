library('testthat')
library('TreeDistData')

test_check("TreeDistData")
