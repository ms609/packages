library("TreeTools", quietly = TRUE)
devtools::load_all()
set.seed(0)

message(Sys.time(), ": Starting.")
message(Sys.time(), ": End.")
