library("testthat", warn.conflicts = FALSE)
library("BigTreeDist")

test_check("BigTreeDist")
