# TreeDistData 1.0.0

- Update abbreviations to match Smith (202X)
- Final `randomTreeDistances` data object.

# TreeDistData 0.1.0

- Initial compilation of analyses and datasets, forked from 'TreeSearch' 
  v0.3.2.9005.
- NOTE: `randomTreeDistances` data object undergoing recalculation.
