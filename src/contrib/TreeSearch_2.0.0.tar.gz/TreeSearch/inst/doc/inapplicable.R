## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)

## ----brazeau, eval = FALSE----------------------------------------------------
# MaximizeParsimony(dataset)

## ----hsj, eval = FALSE--------------------------------------------------------
# hierarchy <- CharacterHierarchy("1" = 2:5, "6" = 7:8)
# MaximizeParsimony(dataset, hierarchy = hierarchy,
#                   inapplicable = "hsj", hsj_alpha = 1.0)

## ----xform, eval = FALSE------------------------------------------------------
# hierarchy <- CharacterHierarchy("1" = 2:5)
# MaximizeParsimony(dataset, hierarchy = hierarchy,
#                   inapplicable = "xform")

## ----hierarchy-manual---------------------------------------------------------
library(TreeSearch)

# Character 1 controls characters 2-5
h <- CharacterHierarchy("1" = 2:5)

# Multiple controlling primaries
h <- CharacterHierarchy("1" = 2:5, "6" = 7:8)

## ----hierarchy-auto-----------------------------------------------------------
names <- c("sup_tail", "sub_tail_colour", "sub_tail_shape",
           "sup_wing", "sub_wing_venation", "other_char")
hierarchy_from_names(names)

## ----example------------------------------------------------------------------
# Create a small dataset with inapplicable characters
mat <- matrix(c(
  # pri  sec1  sec2  indep1  indep2
  "0",  "-",  "-",  "0",    "0",
  "0",  "-",  "-",  "0",    "1",
  "1",  "0",  "0",  "1",    "0",
  "1",  "0",  "1",  "1",    "0",
  "1",  "1",  "0",  "1",    "1",
  "1",  "1",  "1",  "0",    "1"
), nrow = 6, byrow = TRUE,
dimnames = list(paste0("t", 1:6), NULL))
dataset <- TreeTools::MatrixToPhyDat(mat)
hierarchy <- CharacterHierarchy("1" = 2:3)

# Default: Brazeau et al. algorithm (no hierarchy needed)
brazeau_trees <- MaximizeParsimony(dataset, maxReplicates = 3,
                                   targetHits = 2, verbosity = 0)

# HSJ: dissimilarity-metric scoring
hsj_trees <- MaximizeParsimony(dataset, hierarchy = hierarchy,
                               inapplicable = "hsj", hsj_alpha = 1.0,
                               maxReplicates = 3, targetHits = 2,
                               verbosity = 0)

# X-transformation: step-matrix recoding
xform_trees <- MaximizeParsimony(dataset, hierarchy = hierarchy,
                                 inapplicable = "xform",
                                 maxReplicates = 3, targetHits = 2,
                                 verbosity = 0)

