## ----echo = FALSE-------------------------------------------------------------
knitr::opts_chunk$set(fig.width = 7.2, fig.asp = 0.7)
rogueInstalled <- requireNamespace("Rogue", quietly = TRUE)

## ----Load-library-------------------------------------------------------------
library("TreeSearch")

## ----Load-data----------------------------------------------------------------
vinther <- TreeSearch::inapplicable.phyData[["Vinther2008"]]

## ----RNG-version, warn = FALSE------------------------------------------------
# Set a random seed so that random functions in this document are reproducible
RNGversion("3.5.0")
set.seed(0)

## ----first-pass, message = FALSE----------------------------------------------
bestTrees <- MaximizeParsimony(vinther)

## ----plot-tree----------------------------------------------------------------
par(mar = rep(0.25, 4), cex = 0.75) # make plot easier to read
plot(ape::consensus(bestTrees))
TreeLength(bestTrees[[1]], vinther)

## ----plot-label-nodes---------------------------------------------------------
par(mar = rep(0.25, 4), cex = 0.75) # make plot easier to read
majCons <- ape::consensus(bestTrees, p = 0.5)
splitFreqs <- TreeTools::SplitFrequency(majCons, bestTrees) / length(bestTrees)
plot(majCons)
TreeTools::LabelSplits(majCons, round(splitFreqs * 100), unit = "%",
                       col = TreeTools::SupportColor(splitFreqs),
                       frame = "none", pos = 3L)

## ----Jackknife-annotations----------------------------------------------------
nReplicates <- 10
jackTrees <- Resample(vinther, bestTrees, nReplicates = nReplicates,
                      verbosity = 0)

strict <- ape::consensus(bestTrees, p = 1)

par(mar = rep(0, 4), cex = 0.8)
# Take the strict consensus of all trees for each replicate
JackLabels(strict, jackTrees) -> XX

## ----concordance--------------------------------------------------------------
concordance <- QuartetConcordance(strict, vinther)

# Alternative measures:
# concordance <- ClusteringConcordance(strict, vinther)
# concordance <- PhylogeneticConcordance(strict, vinther)

par(mar = rep(0, 4), cex = 0.8)
plot(strict)
TreeTools::LabelSplits(strict, signif(concordance, 3),
                       col = TreeTools::SupportColor(concordance / max(concordance)),
                       frame = "none", pos = 3L)

## ----stability----------------------------------------------------------------
if (rogueInstalled) {
  par(mar = rep(0, 4), cex = 0.8)
  plot(strict, tip.color = Rogue::ColByStability(bestTrees))
} else {
  message("Install the 'Rogue' package to render this block.")
}

## ----find-rogues--------------------------------------------------------------
if (rogueInstalled) {
  Rogue::QuickRogue(bestTrees, p = 1)
} else {
  message("Install the 'Rogue' package to render this block.")
}

## ----cons-without-halk--------------------------------------------------------
if (rogueInstalled) {
  par(mar = rep(0, 4), cex = 0.8)
  noWiwaxia <- lapply(bestTrees, TreeTools::DropTip, "Wiwaxia")
  plot(ape::consensus(noWiwaxia),
       tip.color = Rogue::ColByStability(noWiwaxia))
} else {
  message("Install the 'Rogue' package to render this block.")
}

## ----restore-wiwaxia----------------------------------------------------------
par(mar = rep(0, 4), cex = 0.8)
xx <- TreeTools::RoguePlot(bestTrees, "Wiwaxia", p = 1)

## ----iw-search, message = FALSE-----------------------------------------------
iwTrees <- MaximizeParsimony(vinther, concavity = 10)
par(mar = rep(0.25, 4), cex = 0.75) # make plot easier to read
plot(ape::consensus(iwTrees))

## ----simple-constraints, fig.width = 4, fig.align = "center", message = FALSE----
library("TreeTools", quietly = TRUE)
constraint <- MatrixToPhyDat(c(a = 1, b = 1, c = 0, d = 0, e = 0, f = 0))
characters <- MatrixToPhyDat(matrix(
  c(0, 1, 1, 1, 0, 0,
    1, 1, 1, 0, 0, 0), ncol = 2,
  dimnames = list(letters[1:6], NULL)))
plot(MaximizeParsimony(characters, constraint = constraint,
                       verbosity = -1)[[1]])

## ----complex-constraints, fig.width = 4, fig.align = "center", message = FALSE----
characters <- MatrixToPhyDat(matrix(
  c(0, 0, 1, 1, 1, 1, 1,
    1, 1, 1, 1, 0, 0, 0), ncol = 2,
  dimnames = list(letters[1:7], NULL)))
constraint <- MatrixToPhyDat(matrix(
  c(0, 0, 1, "?", 1, 1,
    1, 1, 1,   1, 0, 0), ncol = 2,
  dimnames = list(letters[1:6], NULL)))
plot(MaximizeParsimony(characters, constraint = constraint,
                       verbosity = -1)[[1]])

