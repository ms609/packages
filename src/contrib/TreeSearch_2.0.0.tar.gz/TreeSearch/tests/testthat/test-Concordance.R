library("TreeTools", quietly = TRUE)

test_that("_Concordance() handles null input", {
  expect_warning(expect_null(QuartetConcordance(BalancedTree(8), NULL)))
  expect_warning(expect_null(PhylogeneticConcordance(BalancedTree(8), NULL)))
  expect_warning(expect_null(ClusteringConcordance(BalancedTree(8), NULL)))
  expect_warning(expect_null(
    MutualClusteringConcordance(BalancedTree(8), NULL)))
  expect_warning(expect_null(
    SharedPhylogeneticConcordance(BalancedTree(8), NULL)))
})

test_that("_Concordance() handles tip mismatch", {
  char <- MatrixToPhyDat(cbind(c(a = 0, b = 0, c = 0, d = 1, e = 1)))
  tree <- BalancedTree(5)
  expect_warning(expect_null(QuartetConcordance(tree, char)),
                 "No overlap between tree labels and dataset.")
  expect_warning(expect_null(ClusteringConcordance(tree, char)),
                 "Could not find 't1', .* in names.dataset.")
})

test_that("QuartetConcordance() works", {
  tree <- BalancedTree(8)
  splits <- as.Splits(tree)
  mataset <- matrix(c(0, 0, 0, 0, 1, 1, 1, 1,  0,
                      0, 1, 0, 1, 0, 1, 0, 1,  0,
                      0, 0, 0, 1, 0, 1, 1, 1,  0,
                      0, 0, 0, 0, 1, 1, 2, 2,  0,
                      0, 0, 1, 1, 2, 2, 3, 3,  0,
                      0, 1, 2, 3, 0, 1, 2, 3,  0), 9,
                    dimnames = list(paste0("t", 1:9), NULL))
  expect_error(QuartetConcordance(tree, mataset),
               "`dataset` must be a phyDat object")
  dat <- MatrixToPhyDat(mataset)
  expect_equal(unname(QuartetConcordance(tree, dat[, 1])), rep(1, 5))
  # plot(tree); nodelabels();
  expect_equal(QuartetConcordance(tree, dat[, 2]),
               c("10" = 1/9, "11" = 0, "12" = 0,
                 "13" = 1/9, "14" = 0, "15" = 0)[names(as.Splits(tree))])
  
  allQuartets <- combn(8, 4)
  for (charI in seq_len(ncol(mataset))) {
    qc <- QuartetConcordance(tree, dat[, charI])
    for (splitI in seq_along(splits)) {
      split <- splits[[splitI]]
      logiSplit <- as.logical(split)
      case <- apply(allQuartets, 2, function (q) {
        qSplit <- logiSplit[q]
        qChar <- mataset[q, charI]
        if (identical(unique(table(qSplit)), 2L) &&
            identical(unique(table(qChar)), 2L)) {
          tbl <- table(qSplit, qChar)
          tab <- paste0(sort(tbl[tbl > 0]), collapse = "")
          switch(tab,
                 "1111" = FALSE,
                 "112" = NA,
                 "13" = NA,
                 "22" = TRUE,
                 "4" = NA,
                 stop(q, ": ", tab)
          )
        } else {
          NA
        }
      })
      expect_equal(sum(case, na.rm = TRUE) / sum(!is.na(case)),
                   unname(qc[as.character(names(split))]))
    }
  }
  
  expect_equal(QuartetConcordance(tree, dat[, c(1:4, 6)]),
               c("10" = (36 + 2 + 9 + 12) / (36 + 18 + 18 + 12 + 6),
                 "11" = ( 6 + 0 + 6 +  2) / ( 6 +  9 +  6 +  2 + 1),
                 "12" = ( 6 + 0 + 0 +  2) / ( 6 +  9 +  9 +  2 + 1),
                 "13" = (36 + 2 + 9 + 12) / (36 + 18 + 18 + 12 + 6),
                 "14" = ( 6 + 0 + 0 +  7) / ( 6 +  9 +  9 +  7 + 1),
                 "15" = ( 6 + 0 + 6 +  7) / ( 6 +  9 +  6 +  7 + 1))[
                   names(as.Splits(tree))]
  )
})

test_that("QuartetConcordance() handles ambiguity", {
  library("TreeTools", quietly = TRUE)
  tree <- BalancedTree(12)
  splits <- as.Splits(tree)
  mataset <- matrix(c(0, 0, "{01}", 0, 0, "{01}", 1, 1, "-", 1, 1, "-",
                      0, 1, "?", 0, 1, "?", 0, 1, "(01)", 0, 1, "(01)",
                      0, 0, "?", 0, 1, "(12)", 0, 1, "(12)", 1, 1, "(12)",
                      0, 0, "?", 0, 0, "?", 1, 1, "?", 2, 2, "?",
                      0, 0, "?", 0, 0, "?", 0, 0, "-", 0, 0, "-",
                      rep("?", 12),
                      0, 1, "?", 2, 3, "?", 0, 1, "-", 2, 3, "-"), 12,
                    dimnames = list(paste0("t", 1:12), NULL))
  dat <- MatrixToPhyDat(mataset)
  
  expectation <- unname(QuartetConcordance(tree, dat)[
    c("14", "16", "18", "19", "21", "23")])
  expect_equal(
    unname(QuartetConcordance(DropTip(tree, paste0("t", 3 * 1:4)), dat)),
    expectation[!is.na(expectation)]
  )
  
  expectation <- unname(QuartetConcordance(tree, dat)[
    c("14", "15", "17", "19", "20", "22")])
  expect_equal(
    unname(QuartetConcordance(DropTip(tree, paste0("t", 3 * 1:4)), dat)),
    expectation[!is.na(expectation)]
  )
})

test_that("QuartetConcordance() handles incomplete data", {
  tree <- BalancedTree(8)
  splits <- as.Splits(tree)
  mataset <- matrix(c(0, 0, 0, 0, 0, 0, 0, 1,
                      rep("?", 8)), 8,
                    dimnames = list(paste0("t", 1:8), NULL))
  dat <- MatrixToPhyDat(mataset)
  
  expect_equal(unname(QuartetConcordance(tree, dat)), rep(NA_real_, 5))
})

test_that("QuartetConcordance() handles non-integer data", {
  tree <- BalancedTree(8)
  splits <- as.Splits(tree)
  mataset <- matrix(c("A", "A", "[AC]", "C", "C", "C", "T", "T", rep("?", 8)),
                    8, dimnames = list(paste0("t", 1:8), NULL))
  dat <- MatrixToPhyDat(mataset)
  
  intSet <- matrix(c("1", "1", "[12]", "2", "2", "2", "4", "4", rep("?", 8)),
                    8, dimnames = list(paste0("t", 1:8), NULL))
  
  expect_equal(QuartetConcordance(tree, dat),
               QuartetConcordance(tree, MatrixToPhyDat(intSet)))
})

test_that(".Rezero() works", {
  expect_equal(TreeSearch:::.Rezero(seq(0, 1, by = 0.1), 0.1), -1:9 / 9)
})

test_that("ConcordanceTable() marginSize top/right strips", {
  skip_if_not_installed("vdiffr")
  data("congreveLamsdellMatrices", package = "TreeSearch")
  dataset <- congreveLamsdellMatrices[[1]][, 1:20]
  tree <- TreeSearch::referenceTree

  vdiffr::expect_doppelganger("conc-tbl-xx34", function() {
    expect_named(
      ConcordanceTable(tree, dataset, marginSize = c(NA, NA, 2, 2)),
      c("info", "relInfo", "quality", "col")
    )
  })

  vdiffr::expect_doppelganger("conc-tbl-all", function() {
    ConcordanceTable(tree, dataset, marginSize = c(2, 2, 2, 2))
  })
  vdiffr::expect_doppelganger("conc-tbl-2", function() {
    capture.output(ConcordanceTable(tree, dataset, marginSize = 2))
  })
})

test_that("ConcordanceTable() paintSize strips", {
  skip_if_not_installed("vdiffr")
  data("congreveLamsdellMatrices", package = "TreeSearch")
  dataset <- congreveLamsdellMatrices[[1]][, 1:20]
  tree <- TreeSearch::referenceTree

  vdiffr::expect_doppelganger("conc-tbl-paint-scalar", function() {
    ConcordanceTable(tree, dataset, paintSize = 1)
  })
  vdiffr::expect_doppelganger("conc-tbl-paint-with-margin", function() {
    ConcordanceTable(tree, dataset, marginSize = 2, paintSize = 1)
  })
})

test_that("ClusteringConcordance() gives sensible values", {
  tree <- BalancedTree(8)
  splits <- as.Splits(tree)
  # None of these characters are informative
  mataset <- matrix(c(0, 0, 0, 0, 0, 0, 0, 1,
                      rep("?", 8)), 8,
                    dimnames = list(paste0("t", 1:8), NULL))
  dat <- MatrixToPhyDat(mataset)
  
  expect_equal(unname(ClusteringConcordance(tree, dat)), rep(NA_real_, 5))
  
  tree <- ape::read.tree(text = "((a, b, c, d, e), (f, g, h));")
  split <- as.Splits(tree)
  
  mataset <- matrix(c(0, 0, 0, 0, 0, 0, 0, 1,
                      0, 0, 0, 0, 0, 1, 1, 1, # Matches split
                      0, 0, 0, 0, 1, 1, 1, 1, # Consistent but not identical
                      0, 0, 0, 1, 1, 1, 1, 1, # Consistent, more different
                      0, 0, 0, 0, 0, 0, 1, 1, # Consistent other way
                      0, 1, 0, 1, 0, 1, 0, 1, # Worst possible
                      0, 0, 0, 0, rep("?", 4), # No information
                      0, 0, 1, 1, rep("?", 4), # No relevant information
                      rep("?", 8)), 8,
                    dimnames = list(letters[1:8], NULL))
  dat <- MatrixToPhyDat(mataset)
  cc <- ClusteringConcordance(tree, dat, return = "all")[, "10", ]
  .Entropy <- function(...) {
    TreeDist::Entropy(c(...) / sum(...))
  }
  .NormExp <- function(a, b, ab) {
    TreeSearch:::.Rezero(
      (.Entropy(a) + .Entropy(b) - .Entropy(ab)) / .Entropy(a),
      TreeSearch:::.ExpectedMI(a, b) / .Entropy(a)
    )
  }
  expect_equal(cc["normalized", ],
               c(NA_real_, 1, 
                 .NormExp(c(3, 5), c(4, 4), c(1, 3, 4)),
                 .NormExp(c(3, 5), c(3, 5), c(2, 3, 3)),
                 .NormExp(c(2, 6), c(3, 5), c(2, 1, 5)),
                 .NormExp(c(3, 5), c(4, 4), c(2, 1, 2, 3)), 
                 NA, NA, NA))
  
  randomset <- matrix(sample(0:1, 8 * 1000, replace = TRUE), 8,
                      dimnames = list(letters[1:8], NULL))
  rat <- MatrixToPhyDat(randomset)
  expect_equal(ClusteringConcordance(tree, rat, normalize = TRUE), c("10" = 0),
               tolerance = 0.05)
})

test_that("ConcordantInformation() works", {
  data(congreveLamsdellMatrices)
  dat <- congreveLamsdellMatrices[[10]]
  tree <- TreeTools::NJTree(dat)
  
  expect_message(ci <- ConcordantInformation(tree, dat),
                 "dataset contains .* bits")
  expect_warning(suppressMessages(eval_val <- Evaluate(tree, dat)))
  expect_equal(eval_val, ci)
  expect_equal(TreeLength(tree, dat, concavity = "prof"),
               unname(ci["noise"]))
  expect_equal(Log2Unrooted(22), unname(ci["treeInformation"]))
  expect_equal(sum(apply(PhyDatToMatrix(dat), 2, CharacterInformation)),
               unname(ci["informationContent"]))
  
  dataset <- MatrixToPhyDat(cbind(setNames(c(rep(1, 11), 2:5), paste0("t", 1:15))))
  tree <- TreeTools::PectinateTree(length(dataset))
  # All non-1 states are singletons → no informative characters → zero concordance
  ci_empty <- suppressMessages(ConcordantInformation(tree, dataset))
  expect_equal(0, unname(ci_empty["signal"]))
  expect_equal(0, unname(ci_empty["noise"]))
  
  dataset <- MatrixToPhyDat(c(a = 1, b = 2, c = 1, d = 2, e = 3, f = 3))
  tree <- TreeTools::PectinateTree(dataset)
  # After T-107, 3-state chars with 6 tips are within the MaddisonSlatkin
  # feasibility threshold (k=3, max=15 tips), so no binary reduction occurs.
  # Signal/noise are computed via the full 3-state profile (no warning).
  ci <- suppressMessages(ConcordantInformation(tree, dataset))
  expect_equal(c(signal = 0.7835082), ci["signal"], tolerance = 1e-5)
  expect_equal(c(noise = 3.1233824), ci["noise"], tolerance = 1e-5)
  expect_equal(c(ignored = 0), ci["ignored"])
  
})

test_that("QACol() handles input", {
  expect_equal(is.na(QACol(c(0, 1, NA, NA, 0), c(0, 1, NA, 0, NA))),
               c(FALSE, FALSE, TRUE,
                 FALSE, # No data = black, quality NA by definition
                 TRUE))
  expect_equal(is.na(QCol(c(0, 1, NA, NA), NA)), c(FALSE, FALSE, TRUE, TRUE))
})
