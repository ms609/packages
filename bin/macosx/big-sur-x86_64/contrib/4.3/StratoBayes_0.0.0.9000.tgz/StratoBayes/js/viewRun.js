"use strict";
window.onload = function(){

  const placeholder = document.getElementById("img_placeholder");
  const root = placeholder.src;

  const svg = document.getElementsByTagName("svg")[0];
  const svgXml = new XMLSerializer().serializeToString(svg);
  const svgBlob = new Blob([svgXml], { type: 'image/svg+xml' });
  const svgURL = URL.createObjectURL(svgBlob);
  svg.style.visibility = "hidden";

  let plots = document.getElementById("plots_table").getElementsByTagName("img");
  for (var i = 0; i != plots.length; i++) {
    plots[i].src = svgURL;
  }

  const refresher = setInterval(function(){
    for (var i = 0; i != plots.length; i++) {
      let img = plots[i];
      let src = new URL(root + img.id + ".png");
      fetch(src)
        .then(response => {
          if (response.ok) {
            return response.blob(); // Returns a promise
          } else {
            throw new Error ("Invalid file response");
          }
        })
        .then(content => {
          if (content.size) {
            img.src = URL.createObjectURL(content);
          }
        })
        .catch(error => {
          console.error("Error loading plots: ", error)
          clearInterval(refresher);
        });
    }
  }, 250);
};
