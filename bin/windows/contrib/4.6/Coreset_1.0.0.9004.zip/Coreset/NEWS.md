# Coreset 1.0.0.9004 (development)

- `DropAdd()` on a distance matrix no longer crashes beyond 46,340 points,
  where its column offsets overflowed an `int`; `ExactMaxMin()`'s warm start
  calls it, so this also affected the exact solver at that size.

- `ExactMaxMin()` reports an `upper` bound on the optimum, and can spend
  `boundSeconds` bracketing the optimum from above before its search, so an
  unproven result still bounds its distance from the optimum. Passing that bound
  back as `upper`, with the selection as `warmStart`, resumes the search.

- `PickPoint()` supports the `"peripheral"` and `"random_furthest"` strategies,
  including where `d` is a function, returning `nSeeds` seeds.
- `FarFirst()` supports `strategy = "random_furthest"` when `d` is a function.
- `MaxEntropy()` is roughly 3-12x faster at large `n`.

# Coreset 1.0.0 (2026-09-09)

`Coreset` selects a representative subset of a fixed candidate set under an
arbitrary distance, solving four discrete location objectives on a distance
matrix, a coordinate matrix, or an on-demand distance-column oracle.

## Max-Min diversity (MMDP / discrete _p_-dispersion)

Maximises the minimum pairwise distance within a subset of size `k`.

- `FarFirst()`: greedy farthest-first selection (Gonzalez 1985), with a choice
  of peripheral seeding strategies, distinct-seed random restarts (`nSeeds`),
  and a robust ensemble default.
- `DropAdd()`: DropAdd tabu search (Porumbel et al. 2011), which can compute
  distances between pairs on the fly rather than needing a complete matrix
  _a priori_.
- `Grasp()`: GRASP with path relinking (Resende et al. 2010), attaining the
  highest `T_k` of the package's heuristics on small to medium instances.
- `ExactMaxMin()`: exact node-packing optimum (Sayyady & Fathi 2016), decided
  by clique search.

## Max-Mean dispersion

- `MaxMean()`: reinforcement-learning-guided tabu search (Nijimbere et al.
  2020), selecting a subset of unrestricted size that maximises the mean
  pairwise distance.

## Discrete _k_-centre

Minimises the largest distance from any element to its nearest selected centre.

- `KCentre()`: the CDSh covering heuristic (Garcia-Diaz et al. 2017, 2019).
- `ExactKCentre()`: exact minimum-cover optimum.

## Max-Sum diversity and maximum entropy

- `ExactMaxSum()`: exact solver for the Max-Sum Diversity Problem (requires
  'highs').
- `MaxEntropy()`: maximum-entropy (maxdet) selection — the mode of a
  determinantal point process — by greedy pivoted-Cholesky selection, and by
  exact enumeration for small instances.

## Scoring and utilities

- `MinDist()`, `MeanDist()` and `KCentreRadius()` score an arbitrary selection
  under the max-min, max-mean and _k_-centre objectives respectively.
- `PickPoint()` exposes the peripheral seed indices directly.
- `DropAdd()` and `Grasp()` accept a `maxCandidates` composable-coreset cap,
  thinning the candidate set with `FarFirst()` before the expensive search and
  mapping the chosen indices back to the original numbering.
- Each solver returns a classed object with `print()`, `format()` and (where
  informative) `summary()` methods giving a terse or detailed report of the
  selection, the achieved objective, and the search effort.
- Solver behaviour is tunable through `options(Coreset.symmetryTolerance = )`,
  which sets how large a rounding discrepancy between `d[i, j]` and `d[j, i]`
  is repaired rather than refused, and `options(Coreset.progress = )`.
